import requests
import json
import os

def search_nazapi(request_id):
    # Dossier pour stocker les résultats
    download_path = "./resultat/"
    if not os.path.exists(download_path):
        os.makedirs(download_path)

    filename = f"{request_id}.txt"
    file_path = os.path.join(download_path, filename)

    # Données de la requête
    data = {
        "token": "1501479747:EOHy2kbG",
        "request": request_id,
        "limit": 75,
        "lang": "fr"
    }
    url = 'https://server.leakosint.com/'
    response = requests.post(url, json=data)

    response_json = response.json()
    if "List" not in response_json:
        print("❌ **Erreur**: Aucun résultat trouvé !")
        return

    list_data = response_json["List"]

    with open(file_path, "w", encoding="utf-8") as file:
        file.write(logo_texte + "\n\n")

        for category, category_data in list_data.items():
            file.write(f"»»————- ★ Trouvée dans : {category} ★ ————-««\n")

            if "Data" not in category_data or not category_data["Data"]:
                print("❌ **Erreur**: Aucun résultat trouvé dans la catégorie !")
                continue

            for data_item in category_data["Data"]:
                if isinstance(data_item, dict):
                    for key, value in data_item.items():
                        file.write(f"{key}: {value}\n")
                else:
                    print("❌ Erreur: Format de données inattendu !")
                    return

            file.write("\n")

    print(f"Les résultats ont été enregistrés dans {file_path}")
    with open(file_path, "r", encoding="utf-8") as file:
        print(file.read())

def main():
    print("NazAPI Search Tool | By OK'RA")
    while True:
        request_id = input("\nEntrez l'ID de la requête à rechercher : ").strip()
        if request_id:
            search_nazapi(request_id)
        else:
            print("⚠️ L'ID de la requête ne peut pas être vide.")

        continuer = input("Voulez-vous effectuer une autre recherche ? (y/n) : ").strip().lower()
        if continuer != 'y':
            print("👋 Au revoir !")
            break
if __name__ == "__main__":
    main()
